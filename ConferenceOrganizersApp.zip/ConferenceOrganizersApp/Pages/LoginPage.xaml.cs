﻿using ConferenceOrganizersApp.Classes;
using System;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;

namespace ConferenceOrganizersApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Page
    {
        int invalidEntry = 0;
        public LoginPage()
        {
            InitializeComponent();

            txbLogin.Focus();
            BtnUpdateCaptcha_Click(null, null);
        }

        private void BtnUpdateCaptcha_Click(object sender, RoutedEventArgs e)
        {

            Random rand = new Random();
            string captcha = "";
            do
            {
                int chr = rand.Next(48, 123);
                if ((chr >= 48 && chr <= 57) || (chr >= 68 && chr <= 90) || (chr >= 97 && chr <= 122))
                    captcha += (char)chr;
                if (captcha.Length == 4)
                    break;
            } while (true);
            txtCaptcha.Text = captcha;
        }

        private void BtnSignIn_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (txbLogin.Text == "") error.AppendLine("Поле \"Логин\" не заполнено!");
            if (pwbPassword.Password == "") error.AppendLine("Поле \"Пароль\" не заполнено!");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString(), "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                invalidEntry++;
                if (invalidEntry == 3)
                {
                    MessageBox.Show("3 попытки неверного входа!\n\nСистема заблокирована на 10 секунд!", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                    invalidEntry = 0;
                    System.Threading.Thread.Sleep(10000);
                }
                return;
            }
            if (txbCaptcha.Text != txtCaptcha.Text)
            {
                MessageBox.Show("Неверно введён код с картинки!", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                BtnUpdateCaptcha_Click(null, null);
                txbCaptcha.Text = "";
                invalidEntry++;
                if (invalidEntry == 3)
                {
                    MessageBox.Show("3 попытки неверного входа!\n\nСистема заблокирована на 10 секунд!", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                    invalidEntry = 0;
                    System.Threading.Thread.Sleep(10000);
                }
                return;
            }
            Users user = new Users();
            try
            {
                int id = Convert.ToInt32(txbLogin.Text);
                user = ClassHelper.db.Users.FirstOrDefault(x => x.idUser == id && x.Password == pwbPassword.Password);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (user == null)
            {
                MessageBox.Show("Неверный логин или пароль!", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                invalidEntry++;
                if (invalidEntry == 3)
                {
                    MessageBox.Show("3 попытки неверного входа!\n\nСистема заблокирована на 10 секунд!", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                    invalidEntry = 0;
                    System.Threading.Thread.Sleep(10000);
                }
                return;
            }
            User _ = new User(user);
            ClassHelper.frmObj.Navigate(new PageLobby());
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            ClassHelper.frmObj.Navigate(new PageLobby());
        }
    }
}
