﻿using ConferenceOrganizersApp.Classes;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace ConferenceOrganizersApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для RegistrationPage.xaml
    /// </summary>
    public partial class RegistrationPage : Page
    {
        string imgLoc = "пусто";
        public RegistrationPage()
        {
            InitializeComponent();

            txbId.Text = User.NextId().ToString();

            cmbGender.ItemsSource = ClassHelper.db.Genders.ToList();
            cmbType.ItemsSource = ClassHelper.db.TypesOfUser.Where(x => x.Name == "Модератор" || x.Name == "Жюри").ToList();
            cmbDirection.ItemsSource = ClassHelper.db.Directions.ToList();
            cmbEvent.ItemsSource = ClassHelper.db.Events.ToList();
        }

        private void CbAttachEvent_Checked(object sender, RoutedEventArgs e)
        {
            if (cbAttachEvent.IsChecked == true) spEvent.Visibility = Visibility.Visible;
            else spEvent.Visibility = Visibility.Collapsed;
        }

        private void ImageLoad_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 2)
            {
                try
                {
                    OpenFileDialog dlg = new OpenFileDialog { Filter = "Файлы изображений (*.png, *.jpg, *.jpeg, *.bmp)|*.png;*.jpg;*.jpeg;*.bmp|Все файлы (*.*)|*.*", Title = "Выберите фото/изображение пользователя" };
                    if (dlg.ShowDialog() == true)
                    {
                        imgLoc = dlg.FileName.ToString();
                        imageUser.Source = new BitmapImage(new Uri(imgLoc));
                    }
                }
                catch (Exception ex) { MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
            }
        }

        private void ImageLoad_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog { Filter = "Файлы изображений (*.png, *.jpg, *.jpeg, *.bmp)|*.png;*.jpg;*.jpeg;*.bmp|Все файлы (*.*)|*.*", Title = "Выберите фото/изображение пользователя" };
                if (dlg.ShowDialog() == true)
                {
                    imgLoc = dlg.FileName.ToString();
                    imageUser.Source = new BitmapImage(new Uri(imgLoc));
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
        }

        private void ImageClear_Click(object sender, RoutedEventArgs e)
        {
            imageUser.Source = (ImageSource)FindResource("UnknownUser");
            imgLoc = "очистить";
        }

        private void TxbPassword_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (((TextBlock)sender).Text == "Password")
            {
                if (pwbPassword.Visibility == Visibility.Collapsed) txbPassword.Focus();
                else pwbPassword.Focus();
            }
            else
            {
                if (pwbRePassword.Visibility == Visibility.Collapsed) txbRePassword.Focus();
                else pwbRePassword.Focus();
            }
        }

        private void CbVisiblePassword_Checked(object sender, RoutedEventArgs e)
        {
            if (((CheckBox)sender).IsChecked.Value)
            {
                txbPassword.Text = pwbPassword.Password;
                txbRePassword.Text = pwbRePassword.Password;
                txbPassword.Visibility = Visibility.Visible;
                txbRePassword.Visibility = Visibility.Visible;
                pwbPassword.Visibility = Visibility.Collapsed;
                pwbRePassword.Visibility = Visibility.Collapsed;
            }
            else
            {
                pwbPassword.Password = txbPassword.Text;
                pwbRePassword.Password = txbRePassword.Text;
                pwbPassword.Visibility = Visibility.Visible;
                pwbRePassword.Visibility = Visibility.Visible;
                txbPassword.Visibility = Visibility.Collapsed;
                txbRePassword.Visibility = Visibility.Collapsed;
            }
        }

        private void TxbPassword_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (((TextBox)sender).Name == "txbPassword")
            {
                if (txbPassword.Text.Length > 0) watermarkPassword.Visibility = Visibility.Collapsed;
                else watermarkPassword.Visibility = Visibility.Visible;
            }
            else
            {
                if (txbRePassword.Text.Length > 0) watermarkRePassword.Visibility = Visibility.Collapsed;
                else watermarkRePassword.Visibility = Visibility.Visible;
            }
        }

        private void PwbPassword_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if(((PasswordBox)sender).Name == "pwbPassword")
            {
                if (pwbPassword.Password.Length > 0) watermarkPassword.Visibility = Visibility.Collapsed;
                else watermarkPassword.Visibility = Visibility.Visible;
            }
            else
            {
                if (pwbRePassword.Password.Length > 0) watermarkRePassword.Visibility = Visibility.Collapsed;
                else watermarkRePassword.Visibility = Visibility.Visible;
            }
        }

        private void BtnOK_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (txbFIO.Text == "") error.AppendLine("Поле \"ФИО\" не заполнено!");
            if (cmbGender.SelectedValue == null) error.AppendLine("Поле со списком \"Пол\" не выбрано!");
            if (cmbType.SelectedValue == null) error.AppendLine("Поле со списком \"Роль\" не выбрано!");
            if (txbMail.Text == "") error.AppendLine("Поле \"Email\" не заполнено!");
            if (txbPhone.Text == "") error.AppendLine("Поле \"Телефон\" не заполнено!");
            if (cmbDirection.SelectedValue == null && cmbDirection.Text == "") error.AppendLine("Поле со списком \"Направление\" не заполнено!");
            if (cbAttachEvent.IsChecked == true && cmbEvent.SelectedValue == null) error.AppendLine("Поле со списком \"Мероприятие\" не заполнено!");
            string password = "";
            string repassword = "";
            if (cbVisiblePassword.IsChecked == false)
            {
                password = pwbPassword.Password;
                repassword = pwbRePassword.Password;
            }
            else
            {
                password = txbPassword.Text;
                repassword = txbRePassword.Text;
            }
            if (password == "") error.AppendLine("Поле \"Пароль\" не заполнено!");
            if (repassword == "") error.AppendLine("Поле \"Повтор пароля\" не заполнено!");
            if (password != repassword) error.AppendLine("Пароли не совпадают!");
            if (password.Length < 6) error.AppendLine("Пароль должен содержать не менее 6 символов!");
            bool IsUpperAndLower = password.Any(ch => char.IsUpper(ch)) && password.Any(ch => char.IsLower(ch));
            bool isSpecialChar = "|!#$%&/()=?»«@£§€{}.-;'\"<>_,".Any(ch => password.Contains(ch));
            bool isDigit = password.Any(ch => char.IsDigit(ch));
            if (!IsUpperAndLower) error.AppendLine("Пароль должен иметь заглавные и строчные буквы!");
            if (!isSpecialChar) error.AppendLine("Пароль должен иметь не менее одного спецсимвола!");
            if (!isDigit) error.AppendLine("Пароль должен иметь не менее одной цифры!");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString(), "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            Users user;
            if (cmbDirection.SelectedValue == null)
            {
                ClassHelper.db.Directions.Add(new Directions() { Name = cmbDirection.Text });
                try
                {
                    ClassHelper.db.SaveChanges();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                Directions direction = ClassHelper.db.Directions.Where(x => x.Name == cmbDirection.Text).FirstOrDefault();
                if (cmbEvent.SelectedValue != null) user = new Users() { FIO = txbFIO.Text, idGender = (int)cmbGender.SelectedValue, idType = (int)cmbType.SelectedValue, Mail = txbMail.Text, Password = password, Phone = txbPhone.Text, idDirection = direction.idDirection, idEvent = (int)cmbEvent.SelectedValue };
                else user = new Users() { FIO = txbFIO.Text, idGender = (int)cmbGender.SelectedValue, idType = (int)cmbType.SelectedValue, Mail = txbMail.Text, Password = password, Phone = txbPhone.Text, idDirection = direction.idDirection, idEvent = null };
            }
            else
            {
                if (cmbEvent.SelectedValue != null) user = new Users() { FIO = txbFIO.Text, idGender = (int)cmbGender.SelectedValue, idType = (int)cmbType.SelectedValue, Mail = txbMail.Text, Password = password, Phone = txbPhone.Text, idDirection = (int)cmbDirection.SelectedValue, idEvent = (int)cmbEvent.SelectedValue };
                else user = new Users() { FIO = txbFIO.Text, idGender = (int)cmbGender.SelectedValue, idType = (int)cmbType.SelectedValue, Mail = txbMail.Text, Password = password, Phone = txbPhone.Text, idDirection = (int)cmbDirection.SelectedValue, idEvent = null };
            }

            if (imgLoc != "пусто" && imgLoc != "очистить")
            {
                FileStream fs = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                user.Photo = br.ReadBytes((int)fs.Length);
            }
            if (imgLoc == "очистить") user.Photo = null;
            ClassHelper.db.Users.Add(user);
            try
            {
                ClassHelper.db.SaveChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            User _ = new User(user);
            MessageBox.Show($"Новый {User.CurrentUser.TypeUser.ToLower()} успешно зарегистрирован!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            ClassHelper.frmObj.Navigate(new PageUsers());
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            ClassHelper.frmObj.Navigate(new PageUsers());
        }
    }
}
