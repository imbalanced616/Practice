﻿using ConferenceOrganizersApp.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ConferenceOrganizersApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageUsers.xaml
    /// </summary>
    public partial class PageUsers : Page
    {
        public PageUsers()
        {
            InitializeComponent();

            if (User.CurrentUser.TypeUser == "Организатор") contextMenu.Visibility = Visibility.Visible;

            dtgUsers.ItemsSource = ClassHelper.db.Users.ToList();
            CountItems.Text = dtgUsers.Items.Count.ToString();
        }

        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            List<Users> users = ClassHelper.db.Users.ToList();
            if (txbSearch.Text.Count() != 0) dtgUsers.ItemsSource = users.Where(x => x.idUser.ToString().Contains(txbSearch.Text.ToLower())
            || x.FIO.ToLower().Contains(txbSearch.Text.ToLower()) || x.Countries.Name.ToLower().Contains(txbSearch.Text.ToLower()) || x.TypesOfUser.Name.ToLower().Contains(txbSearch.Text.ToLower()));
            else dtgUsers.ItemsSource = users;
            CountItems.Text = dtgUsers.Items.Count.ToString();
        }

        private void MenuRegistration_Click(object sender, RoutedEventArgs e)
        {
            ClassHelper.frmObj.Navigate(new RegistrationPage());
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassHelper.frmObj.Navigate(new PageLobby());
        }
    }
}
