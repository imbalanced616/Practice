﻿using ConferenceOrganizersApp.Classes;
using ConferenceOrganizersApp.Pages.Add_Edit;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace ConferenceOrganizersApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageEvents.xaml
    /// </summary>
    public partial class PageEvents : Page
    {
        public PageEvents()
        {
            InitializeComponent();
            dtgEvents.ItemsSource = ClassHelper.db.Events.ToList();
            CountItems.Text = dtgEvents.Items.Count.ToString();

            if (User.CurrentUser.TypeUser == "Организатор")
            {
                menuAdd.Visibility = Visibility.Visible;
                menuEdit.Visibility = Visibility.Visible;
                menuSepatator.Visibility = Visibility.Visible;
                menuDelete.Visibility = Visibility.Visible;
            }

            List<Directions> directions = ClassHelper.db.Directions.ToList();
            foreach (Directions direction in directions)
            {
                MenuItem menuItem = new MenuItem() { Header = direction.Name };
                menuItem.Click += (s, e) => MenuFilter_Click(s, e);
                menuFilter.Items.Add(menuItem);
            }
            MenuItem menuReset = new MenuItem() { Header = "Сброс" };
            menuReset.Click += (s, e) => MenuUpdate_Click(s, e);
            menuFilter.Items.Add(new Separator() { Margin = new Thickness(0, 3, 0, 3) });
            menuFilter.Items.Add(menuReset);
        }

        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            List<Events> events = ClassHelper.db.Events.ToList();
            if (txbSearch.Text.Count() != 0) dtgEvents.ItemsSource = events.Where(x => x.idEvent.ToString().Contains(txbSearch.Text.ToLower())
            || x.Name.ToLower().Contains(txbSearch.Text.ToLower()) || x.NameDirection.ToLower().Contains(txbSearch.Text.ToLower()) || x.Date.ToString().Contains(txbSearch.Text.ToLower()));
            else dtgEvents.ItemsSource = events;
            CountItems.Text = dtgEvents.Items.Count.ToString();
        }

        private void MenuFilter_Click(object sender, RoutedEventArgs e)
        {
            MenuItem m = (MenuItem)sender;
            List<Events> events = ClassHelper.db.Events.ToList();
            dtgEvents.ItemsSource = events.Where(x => x.NameDirection == m.Header.ToString()).ToList();
            CountItems.Text = dtgEvents.Items.Count.ToString();
        }

        private void MenuAddOrEdit_Click(object sender, RoutedEventArgs e)
        {
            if (((MenuItem)sender).Header.ToString() == "Добавить") ClassHelper.frmObj.Navigate(new AddEditPageEvent(null));
            else if ((Events)dtgEvents.SelectedItem != null) ClassHelper.frmObj.Navigate(new AddEditPageEvent((Events)dtgEvents.SelectedItem));
            else MessageBox.Show("Выберите мероприятие для изменения.", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        private void MenuUpdate_Click(object sender, RoutedEventArgs e)
        {
            dtgEvents.ItemsSource = ClassHelper.db.Events.ToList();
            CountItems.Text = dtgEvents.Items.Count.ToString();
            txbSearch.Clear();
        }

        private void MenuDelete_Click(object sender, RoutedEventArgs e)
        {
            List<Events> list = dtgEvents.SelectedItems.Cast<Events>().ToList();
            if (list.Count == 0)
            {
                MessageBox.Show($"Выберите мероприятия для удаления.", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (list.Count == 1)
            {
                if (MessageBox.Show($"Вы точно хотите удалить запись №{list.First().idEvent}?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    try
                    {
                        ClassHelper.db.Database.ExecuteSqlCommand("update ConferenceOrganizers.dbo.Users set idEvent = null where idEvent = @id", new SqlParameter("@id", list.First().idEvent));
                        ClassHelper.db.Database.ExecuteSqlCommand("update ConferenceOrganizers.dbo.Activities set idEvent = null where idEvent = @id", new SqlParameter("@id", list.First().idEvent));
                        ClassHelper.db.Events.Remove(list.First());
                        ClassHelper.db.SaveChanges();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                }
                else return;
            }
            if (list.Count > 1)
            {
                if (MessageBox.Show($"Вы точно хотите удалить записи {list.Count}?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    try
                    {
                        foreach (Events ev in list)
                        {
                            ClassHelper.db.Database.ExecuteSqlCommand("update ConferenceOrganizers.dbo.Users set idEvent = null where idEvent = @id", new SqlParameter("@id", ev.idEvent));
                            ClassHelper.db.Database.ExecuteSqlCommand("update ConferenceOrganizers.dbo.Activities set idEvent = null where idEvent = @id", new SqlParameter("@id", ev.idEvent));
                            ClassHelper.db.Events.Remove(ev);
                            ClassHelper.db.SaveChanges();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                }
                else return;
            }
            MessageBox.Show("Данные удалены!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            dtgEvents.ItemsSource = ClassHelper.db.Events.ToList();
            CountItems.Text = dtgEvents.Items.Count.ToString();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassHelper.frmObj.Navigate(new PageLobby());
        }
    }
}
