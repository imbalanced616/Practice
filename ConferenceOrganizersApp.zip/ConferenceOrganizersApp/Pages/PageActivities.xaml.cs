﻿using ConferenceOrganizersApp.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ConferenceOrganizersApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageActivities.xaml
    /// </summary>
    public partial class PageActivities : Page
    {
        public PageActivities()
        {
            InitializeComponent();
            dtgActivies.ItemsSource = ClassHelper.db.ActivitiesInEvents.ToList();
            CountItems.Text = dtgActivies.Items.Count.ToString();

            //var activies = from a in ClassHelper.db.Activities
            //             join aie in ClassHelper.db.ActivitiesInEvents on a.idActivity equals aie.idActivity
            //             select new { a.idActivity, a.idEvent, a.idWinner, aie.idAIE, aie.Name, aie.Day, aie.StartTime,
            //                 aie.idModerator, aie.idJury_1, aie.idJury_2, aie.idJury_3, aie.idJury_4, aie.idJury_5 };
        }

        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txbSearch.Text.Count() != 0) dtgActivies.ItemsSource = ClassHelper.db.ActivitiesInEvents.Where(x => x.idAIE.ToString().Contains(txbSearch.Text.ToLower())
            || x.Name.ToLower().Contains(txbSearch.Text.ToLower()) || x.Day.ToString().Contains(txbSearch.Text.ToLower()) || x.StartTime.ToLower().Contains(txbSearch.Text.ToLower())).ToList();
            else dtgActivies.ItemsSource = ClassHelper.db.ActivitiesInEvents.ToList();
            CountItems.Text = dtgActivies.Items.Count.ToString();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassHelper.frmObj.Navigate(new PageLobby());
        }
    }
}
