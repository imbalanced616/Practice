﻿using ConferenceOrganizersApp.Classes;
using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace ConferenceOrganizersApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageLobby.xaml
    /// </summary>
    public partial class PageLobby : Page
    {
        public PageLobby()
        {
            InitializeComponent();

            User _ = new User();

            if (User.CurrentUser.Photo != null) imageUser.Source = BitmapFrame.Create(new MemoryStream(User.CurrentUser.Photo), BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
            else imageUser.Source = (ImageSource)FindResource("UnknownUser");

            if (User.CurrentUser != null)
            {
                if (User.CurrentUser.TypeUser == "Организатор") txtTitle.Text = $"Окно Организатора";
                else if (User.CurrentUser.TypeUser == "Модератор") txtTitle.Text = $"Окно Модератора";
                else if (User.CurrentUser.TypeUser == "Жюри") txtTitle.Text = $"Окно Жюри";
                else if (User.CurrentUser.TypeUser == "Участник") txtTitle.Text = $"Окно Участника";
                else txtTitle.Text = $"Окно Пользователя";
            }

            int hours = Convert.ToInt32(DateTime.Now.ToString("HH"));
            if (hours >= 9 && hours < 11) txtHello.Text = "Доброе утро!";
            else if (hours >= 11 && hours < 18) txtHello.Text = "Добрый день!";
            else if (hours >= 19 && hours < 24) txtHello.Text = "Добрый вечер!";
            else txtHello.Text = "Доброй ночи!";

            if (User.CurrentUser.FIO != null)
            {
                string[] fio = User.CurrentUser.FIO.Split(' ');
                if (fio.Length == 3)
                {
                    if (User.CurrentUser.IdGender == 1) txtFIO.Text = $"Mr. {fio[1]} {fio[2]}";
                    else txtFIO.Text = $"Ms. {fio[1]} {fio[2]}";
                }
            }

            if (User.CurrentUser.TypeUser == "Пользователь") btnSignInOrPersonalAccount.Content = "Войти";
            else btnSignInOrPersonalAccount.Content = "Выйти";
        }

        private void BtnSignInOrPersonalAccount_Click(object sender, RoutedEventArgs e)
        {
            if (((Button)sender).Content.ToString() == "Войти") ClassHelper.frmObj.Navigate(new LoginPage());
            else
            {
                ClassHelper.frmObj.Navigate(new LoginPage());
                User _ = new User();
            }
        }

        private void BtnEvents_Click(object sender, RoutedEventArgs e)
        {
            ClassHelper.frmObj.Navigate(new PageEvents());
        }

        private void BtnActivities_Click(object sender, RoutedEventArgs e)
        {
            ClassHelper.frmObj.Navigate(new PageActivities());
        }

        private void BtnUsers_Click(object sender, RoutedEventArgs e)
        {
            ClassHelper.frmObj.Navigate(new PageUsers());
        }
    }
}
