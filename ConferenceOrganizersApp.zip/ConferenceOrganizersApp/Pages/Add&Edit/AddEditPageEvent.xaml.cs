﻿using ConferenceOrganizersApp.Classes;
using Microsoft.Win32;
using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace ConferenceOrganizersApp.Pages.Add_Edit
{
    /// <summary>
    /// Логика взаимодействия для AddEditPageEvent.xaml
    /// </summary>
    public partial class AddEditPageEvent : Page
    {
        private readonly Events _currentItem = new Events();
        public AddEditPageEvent(Events selectedItem)
        {
            InitializeComponent();
            if (selectedItem != null)
            {
                _currentItem = selectedItem;
                txtTitle.Text = "Изменение мероприятия";
                btnAddEdit.Content = "Изменить";
            }
            cmbCities.ItemsSource = ClassHelper.db.Cities.ToList();
            DataContext = _currentItem;
        }

        private void ImageLoad_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 2)
            {
                try
                {
                    OpenFileDialog dlg = new OpenFileDialog { Filter = "Файлы изображений (*.png, *.jpg, *.jpeg, *.bmp)|*.png;*.jpg;*.jpeg;*.bmp|Все файлы (*.*)|*.*", Title = "Выберите лого мероприятия" };
                    if (dlg.ShowDialog() == true)
                    {
                        imageUser.Source = new BitmapImage(new Uri(dlg.FileName.ToString()));
                        FileStream fs = new FileStream(dlg.FileName.ToString(), FileMode.Open, FileAccess.Read);
                        BinaryReader br = new BinaryReader(fs);
                        _currentItem.Logo = br.ReadBytes((int)fs.Length);
                    }
                }
                catch (Exception ex) { MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
            }
        }

        private void ImageLoad_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog { Filter = "Файлы изображений (*.png, *.jpg, *.jpeg, *.bmp)|*.png;*.jpg;*.jpeg;*.bmp|Все файлы (*.*)|*.*", Title = "Выберите лого мероприятия" };
                if (dlg.ShowDialog() == true)
                {
                    imageUser.Source = new BitmapImage(new Uri(dlg.FileName.ToString()));
                    FileStream fs = new FileStream(dlg.FileName.ToString(), FileMode.Open, FileAccess.Read);
                    BinaryReader br = new BinaryReader(fs);
                    _currentItem.Logo = br.ReadBytes((int)fs.Length);
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
        }

        private void ImageClear_Click(object sender, RoutedEventArgs e)
        {
            _currentItem.Logo = null;
            imageUser.Source = (ImageSource)FindResource("UnknownEvent");
        }

        private void BtnAddOrEdit_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentItem.Name)) error.AppendLine("Укажите название мероприятия.");
            if (string.IsNullOrWhiteSpace(_currentItem.Date.ToString())) error.AppendLine("Укажите дату.");
            if (string.IsNullOrWhiteSpace(_currentItem.Days.ToString())) error.AppendLine("Укажите дни.");
            if (string.IsNullOrWhiteSpace(_currentItem.idCity.ToString())) error.AppendLine("Укажите город.");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString(), "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (_currentItem.idEvent == 0) ClassHelper.db.Events.Add(_currentItem);
            try
            {
                ClassHelper.db.SaveChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (btnAddEdit.Content.ToString() == "Добавить") MessageBox.Show("Новое мероприятие успешно добавлено!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            else MessageBox.Show("Мероприятие успешно изменено!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            ClassHelper.frmObj.Navigate(new PageEvents());
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            ClassHelper.frmObj.Navigate(new PageEvents());
        }
    }
}
