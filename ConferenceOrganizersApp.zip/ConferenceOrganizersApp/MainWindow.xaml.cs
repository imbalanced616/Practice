﻿using ConferenceOrganizersApp.Classes;
using ConferenceOrganizersApp.Pages;
using System.Windows;

namespace ConferenceOrganizersApp
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ClassHelper.frmObj = FrameWindow;
            ClassHelper.frmObj.Navigate(new PageLobby());
        }
    }
}
