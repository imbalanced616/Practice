﻿using System;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;

namespace ConferenceOrganizersApp.Classes
{
    public class User
    {
        public int Id { get; set; }
        public string FIO { get; set; }
        public byte[] Photo { get; set; }
        public int? IdGender { get; set; }
        public DateTime? DateOfBirthday { get; set; }
        public int? Age
        {
            get
            {
                int age = DateTime.Today.Year - ((DateTime)DateOfBirthday).Year;
                if (((DateTime)DateOfBirthday).AddYears(age) < DateTime.Today) age--;
                return age;
            }
        }
        public string AgeType
        {
            get
            {
                int age = Convert.ToInt32(Age) % 10;
                if (age == 1) return "год";
                else if (age == 2 || age == 3 || age == 4) return "года";
                else return "лет";
            }
        }
        public string Mail { get; set; }
        public string Password { get; set; }
        public string Phone { get; set; }
        public int? IdCountry { get; set; }
        public int? IdType { get; set; }
        public int? IdEvent { get; set; }
        public int? IdDirection { get; set; }
        public string TypeUser
        {
            get
            {
                string type = "";
                if (IdType != null) type = ClassHelper.db.TypesOfUser.Where(x => x.idType == IdType).FirstOrDefault().Name;
                return type;
            }
        }

        public static User CurrentUser { get; set; }

        public User()
        {
            if (CurrentUser == null)
            {
                TypesOfUser _tou = ClassHelper.db.TypesOfUser.Where(x => x.Name == "Пользователь").FirstOrDefault();
                if (_tou != null && _tou.idType != 0) IdType = _tou.idType;
                CurrentUser = this;
            }
        }
        public User(int idUser, byte[] photo, string fio, int idGender, DateTime dateOfBirthday, string mail, string password, string phone, int idCountry, int idType, int idEvent, int idDirection)
        {
            Id = idUser;
            FIO = fio;
            Photo = photo;
            IdGender = idGender;
            DateOfBirthday = dateOfBirthday;
            Mail = mail;
            Password = password;
            Phone = phone;
            IdCountry = idCountry;
            IdType = idType;
            IdEvent = idEvent;
            IdDirection = idDirection;
            CurrentUser = this;
        }
        public User(Users user)
        {
            Id = user.idUser;
            FIO = user.FIO;
            Photo = user.Photo;
            IdGender = user.idGender;
            DateOfBirthday = user.DateOfBirthday;
            Mail = user.Mail;
            Password = user.Password;
            Phone = user.Phone;
            IdCountry = user.idCountry;
            IdType = user.idType;
            IdEvent = user.idEvent;
            IdDirection = user.idDirection;
            CurrentUser = this;
        }

        public static int NextId()
        {
            return (int)ClassHelper.db.Database.SqlQuery<decimal>("SELECT IDENT_CURRENT('Users') + 1").First();
        }
    }
}
