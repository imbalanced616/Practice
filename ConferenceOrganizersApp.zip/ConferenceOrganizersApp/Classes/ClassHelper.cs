﻿using System.Windows;
using System.Windows.Controls;

namespace ConferenceOrganizersApp.Classes
{
    public class ClassHelper
    {
        public static Frame frmObj;

        public static ConferenceOrganizersEntities db = new ConferenceOrganizersEntities();
    }
}
